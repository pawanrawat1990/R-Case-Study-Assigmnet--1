
################################### R Assignment ##################################

###### Question -1 ##################

sessionInfo()

###### Question-2 ###################

abc <- 3

###### Question-3 ####################

a <- 1:10

b <- c("a","b","c")

c <- c(T,F)

###### Question- 4 ##################

ls()


###### Question-5 ##################


x <- c(4,4,5,6,7,2,9)
## 5-a ########################

length(x) ## 7 ###
mean(x) #### 5.28 ####
sum(x) ## 37 ####
max(x) ## 9 #####
min(x) ## 2 ####
var(x) ## 5.23 ###

#### 5-b ###########

print(x[3]) ### 3rd Element

i= x%%2==1

print(x[i]) ### 5, 7, 9 ####

print(x[2:6]) ### 2 to 6 ###


###### Question- 6 #############


data <- matrix(1:24,6,4)

##### Question-7 ##############


Req_data <- data.frame(StoreID =  c(111, 208, 113, 408),
                       Tenure =  c(25, 34, 28, 52),
                       StoreType =  c("Type1", "Type2", "Type1", "Type1"),
                       status = c("Poor", "Improved", "Excellent", "Poor"))

##### Question-8 ####################


print(Req_data[,c(1,2)]) ## Store ID, Tenure ##

print(Req_data[,c(3,4)]) ## StoreType and Status ###

print(Req_data[,"Tenure"]) ## Tenure ######


############# Question-9 #######################

Ethnicity <-  c("White", "African amrican", "White", "Asian")

class(Ethnicity) ## characters ####
Ethnicity <- as.factor(Ethnicity)

status <-  as.factor(c("Poor", "Improved", "Excellent", "Poor"))

class(status)

outcome <-  c(1, 3, 2, 4, 3, 1, 1)

outcome <- factor(outcome, levels=c(1,2,3,4),labels=c('Poor','Average','Good','Excellent'))

outcome[order(outcome)]

################## Question- 10 ########################



h <- c(25, 26, 18, 39)
j <- matrix(1:10,5,2)
k <- c("one", "two", "three")
l <- "My_First_List"

mylist <- list(title = l,ages= list(h, j, k))
print(mylist)

print(mylist[[2]])

print(mylist["ages"][1])


############# Question-11 ############################

stores <- read.csv("D:/R Analytics/Analytixlabs/Assignments/stores.csv")

# install.packages("Hmisc")
# library(Hmisc)
describe(stores)

summary(stores)

### We can also use user defined fucntions for descriptive statistics ###############


############ Question- 12 ###############################

with(stores,summary(stores$OperatingCost))

#### only difference is that here we are getting summary of one column, descriptive stats is same ##############################



### Question- 13 #####################################

class(stores)
names(stores)
length(stores)
dim(stores)
str(stores)
head(stores)
tail(stores)
fix(stores)

#### Question - 14 ######################################

stores$total_cost <- stores$OperatingCost+stores$AcqCostPercust

data1 <- transform(stores,total_cost1=OperatingCost+AcqCostPercust)

########## Question- 15 ###############################

stores$store_class <- ifelse(stores$TotalSales<120,"Low Perform Store",
                             ifelse(stores$TotalSales>240,"High Perform Store","Average Perform Store"))


######## Question - 16 ###################################

names(stores)
names(stores)[names(stores)=="AcqCostPercust"] <- "AcqCost"

####### Question - 17 ####################################


sum(is.na(stores))

stores[is.na(stores)] <- 0  #### Impute with 0 ###########


stores_1 <- stores[!is.na(stores)] ##### Deleting all missing value observations ###

##### Question - 18 #################
## a ####
library(dplyr)

names(stores)
newstores <- arrange(stores,StoreType)
new_stores <- arrange(stores,Location,desc(TotalSales))

##### Question-19 ###################


vector_1 <- as.Date(c("2014-06-22", "2014-02-13"))
class(vector_1)

vector_2 <- c("01/05/1965", "08/16/1975")

date_vector <-  as.Date(vector_2,format="%m/%d/%Y")


################ Question-20 ##################


stores_sub1 <- stores[,c(5,7,8,9)]

stores_sub2 <- subset(stores,select = -c(5,7,8,9))

stores_sub3 <- stores[1:10,]

stores_sub4 <- stores[stores$StoreType=="Apparel" & stores$TotalSales>100,]

stores_sub5 <- stores[stores$TotalSales>100 & stores$TotalSales<300,c("StoreCode","StoreName","Location","TotalSales")]

stores_sub6 <- stores[stores$StoreType=="Electronincs" & stores$TotalSales>100,c(1:10)]

#### There is spelling mistake of electronics in dataset, so i have used the incorrect one only for slicing ####################















