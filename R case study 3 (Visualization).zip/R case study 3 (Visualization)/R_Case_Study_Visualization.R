
setwd("D:/R Analytics/Analytixlabs/R case study 3 (Visualization)")

sales_data <- read.csv("SalesData.csv")

library(ggplot2)
library(cowplot)

#### Need help to clean these below charts for better visualization, issue in data labelling ##############


### Question-1 ########################

library(tidyr)
df = gather(sales_data, key = "Sales_Year", value = "Sales", 9:10)

####### Question-1 ###########################

p1 <- ggplot(df, aes(x=Region, y=Sales, fill=Sales_Year)) +
  geom_bar(stat="identity", position=position_dodge())+ geom_text(aes(label = df$Sales), position=position_dodge(width=0.9), vjust=-0.5)


########## Question-2 #########################

bar <- ggplot(data = sales_data,aes(x ="", y=Sales2016,fill= Region)) + 
  geom_bar(width = 1,stat = "identity")

pie_chart <- bar+coord_polar("y",start=0)+scale_fill_brewer(palette = "Dark2")+theme_minimal() ### 

pie_chart2 <- ggplot(transform(transform(sales_data, sales=Sales2016/sum(Sales2016)), labPos=cumsum(sales)-sales/2), 
       aes(x="", y = Sales2016, fill = Region)) +
  geom_bar(width = 1, stat = "identity") +
  scale_fill_manual(values = c("red", "yellow","blue", "green", "cyan")) +
  coord_polar(theta = "y") +
  labs(title = "Percentage Sales per Region") + 
  geom_text(aes(y=labPos, label=scales::percent(sales)))




#### Question-3 ##########################

regions_grp <- group_by(df,Region,Tier,Sales_Year) %>% 
  summarise(Sales=sum(Sales))

ggplot(regions_grp, aes(x=Tier, y=Sales, fill=Sales_Year, 
               group=Region,
               shape=Region,
               color=Region))+
  geom_bar(stat="identity", position=position_dodge())+ geom_text(aes(label = regions_grp$Sales), position=position_dodge(width=0.9), vjust=-0.5)+
  scale_x_discrete("Tier") +
  scale_y_continuous("Sales")


###### Question-4 #######################
library(dplyr)

ggplot(subset(df,Region %in% c("East")), aes(x=State, y=Sales, fill=Sales_Year)) +
  geom_bar(stat="identity", position=position_dodge()) 

##### NY, GA , RI and SC  are the decline state #############################



################## Question- 5 #######################

df1 <- gather(sales_data, key = "Units_Year", value = "Units",11:12)

ggplot(subset(df1,Tier %in% c("High")), aes(x=Division, y=Units, fill=Units_Year)) +
  geom_bar(stat="identity", position=position_dodge())+theme(axis.text.x = element_text(angle = 90, hjust = 1))


###### Question-6 ####################################

df$Qtr <- ifelse(sales_data$Month=="Jan" |sales_data$Month=="Feb" | sales_data$Month=="Mar","Q1",
                         ifelse(sales_data$Month=="Apr" |sales_data$Month=="May" | sales_data$Month=="Jun","Q2",
                                ifelse(sales_data$Month=="Jul" |sales_data$Month=="Aug" | sales_data$Month=="Sep","Q3","Q4")))


####### Question-7 ##################################

ggplot(df, aes(x=Qtr, y=Sales, fill=Sales_Year)) +
  geom_bar(stat="identity", position=position_dodge())


########## Question-8 ###########################

df2 <- subset(df,Sales_Year %in% c("Sales2015"))

Qtr1 <-  ggplot(subset(df2,Qtr %in% c("Q1")), aes(x=Qtr, y=Sales, fill=Tier)) +
  geom_bar(stat="identity")+coord_polar("y",start=0)+scale_fill_brewer(palette = "Dark2")+theme_minimal()


Qtr2 <-  ggplot(subset(df2,Qtr %in% c("Q2")), aes(x=Qtr, y=Sales, fill=Tier)) +
  geom_bar(stat="identity")+coord_polar("y",start=0)+scale_fill_brewer(palette = "Dark2")+theme_minimal()

Qtr3 <- ggplot(subset(df2,Qtr %in% c("Q3")), aes(x=Qtr, y=Sales, fill=Tier)) +
  geom_bar(stat="identity")+coord_polar("y",start=0)+scale_fill_brewer(palette = "Dark2")+theme_minimal()


Qtr4 <-  ggplot(subset(df2,Qtr %in% c("Q4")), aes(x=Qtr, y=Sales, fill=Tier)) +
  geom_bar(stat="identity")+coord_polar("y",start=0)+scale_fill_brewer(palette = "Dark2")+theme_minimal()

plot_grid(Qtr1,Qtr2,Qtr3,Qtr4, nrow=2)


### End #################


