
setwd("D:/R Analytics/Analytixlabs/R case study 2 (Credit card)")

cust_acquisition <- read.csv("Customer Acqusition.csv")

repayment <- read.csv("Repayment.csv")
spend <- read.csv("Spend.csv")

### Question-1 ###################

### a ##################
cust_acquisition$Age[cust_acquisition$Age<18] <- mean(cust_acquisition$Age,na.rm = T)

merge_data <- merge(spend,cust_acquisition,by.x="Customer",by.y = "Customer",all.x = T)

##### b #############
merge_data$Amount <- ifelse(merge_data$Amount>merge_data$Limit,0.50*merge_data$Limit,merge_data$Amount)

repayment$X <- NULL
repayment_updated <-  repayment[1:1500,]


merge_data2 <- merge(repayment_updated,cust_acquisition,by.x="Customer",by.y = "Customer",all.x = T)

##### c ############################
merge_data2$Amount <- ifelse(merge_data2$Amount>merge_data2$Limit,merge_data2$Limit,merge_data2$Amount)


##### Question-2 #######################

length(unique(cust_acquisition$Customer)) ## 100 distinct customer #########

length(unique(cust_acquisition$Product)) ## 3 categories ############



library(dplyr)

#### c ################
grp_spend  <- group_by(merge_data,Customer) %>% 
  summarise(Avg_spend=mean(Amount)) ### Customer_wise avg spend ###

##### d ##################
grp_avg_repayment <- group_by(merge_data2,Customer) %>%
  summarise(avg_repayment=mean(Amount)) ### Customer_wise Repayment


######## e ###################

merge_data$Month <- as.Date(merge_data$Month,format="%d-%B-%y")
merge_data$updated_months <- months(merge_data$Month)
merge_data$updated_months <- factor(merge_data$updated_months ,levels=month.name, ordered = T)
merge_data$year <- year(merge_data$Month)

merge_data2$Month <- as.Date(merge_data2$Month,format="%d-%B-%y")
merge_data2$updated_months <- months(merge_data2$Month)
merge_data2$updated_months <- factor(merge_data2$updated_months ,levels=month.name, ordered = T)
merge_data2$year <- year(merge_data2$Month)


grp_month_spend <- group_by(merge_data,year,updated_months)%>% summarise(total_spend=sum(Amount))
grp_month_repay <- group_by(merge_data2,year,updated_months)%>% summarise(total_repay=sum(Amount))

combine_spend_repay <- merge(grp_month_spend,grp_month_repay,by.x=c("year","updated_months"),by.y = c("year","updated_months"),all.x = T)

combine_spend_repay$monthly_profit <- combine_spend_repay$total_repay-combine_spend_repay$total_spend

######### Interest Earned #################################
combine_spend_repay$interest_earned <- ifelse(combine_spend_repay$monthly_profit>0,0.029*combine_spend_repay$monthly_profit,0)




#### f #########################
grp_type <- group_by(merge_data,Type) %>% summarise(total_spend=sum(Amount))

sorted_type <- grp_type[order(grp_type$total_spend,decreasing = T),]
top_five_type <- sorted_type[1:5,] ### top 5 product type based on spend ###

#### g ############################
grp_city_spend <- group_by(merge_data,City) %>% summarise(total_spend=sum(Amount))
grp_city_spend[which.max(grp_city_spend$total_spend),] #### COCHIN #########



merge_data$age_group <- ifelse(merge_data$Age<30,"less than 30",
                                     ifelse(merge_data$Age<60 & merge_data$Age>30,"30-60","more than 60"))

grp_age_spend <- group_by(merge_data,age_group) %>% summarise(total_spend=sum(Amount))
##### Age Group less than 30 has more spending ###############



grp_repayment <- group_by(merge_data2,Customer) %>% summarise(total_spend=sum(Amount))
sorted_repayment <- grp_repayment[order(grp_repayment$total_spend, decreasing = T),]
top_10_repayment <- sorted_repayment[1:10,]


#### Question -3 #################################

library(lubridate)


combine_grp <- group_by(merge_data,City,Product,year) %>% 
  summarise(spend=sum(Amount))  ### city wise product spend on yearly basis ###

library(ggplot2)

plot1 <- ggplot(combine_grp, 
       aes(x=factor(year), y=spend, 
           group=City,
           shape=City,
           color=City)) + 
  geom_line() + 
  geom_point() +
  scale_x_discrete("year") +
  scale_y_continuous("spend") + 
  facet_grid(.~Product)  ### Can be presented in many ways based on the requirement ###



#### Question-4 #####################################

monthly_spend <- group_by(merge_data,updated_months, City) %>% 
  summarise(spend=sum(Amount))



plot2 <- ggplot(monthly_spend, 
                aes(x=updated_months, y=spend, 
                    group=City,
                    shape=City,
                    color=City)) + 
  geom_line() + 
  geom_point() +
  scale_x_discrete("Updated_months") +
  scale_y_continuous("spend") #### Monthly Comparison ####


air_tickets_data <- merge_data[merge_data$Type=="AIR TICKET",]
yearly_spend <- group_by(air_tickets_data,year) %>% summarise(spend=sum(Amount))



plot3 <- ggplot(yearly_spend, 
                aes(x=factor(year), y=spend)) + 
  geom_bar(stat = "identity") + 
  scale_x_discrete("yearly_spend") +
  scale_y_continuous("spend") #### Yearly Comparison ####



monthly_spend_prod <- group_by(merge_data,updated_months,Product) %>% 
  summarise(spend=sum(Amount))



ggplot(monthly_spend_prod, 
       aes(x=updated_months, y=spend, 
           group=Product,
           shape=Product,
           color=Product)) + 
  geom_line() + 
  geom_point() +
  scale_x_discrete("Updated_months") +
  scale_y_continuous("spend") ### Monthly spend for each product #########



merge_data2$Month <- as.Date(merge_data2$Month,format="%d-%B-%y")
merge_data2$updated_months <- months(merge_data2$Month)
merge_data2$year <- year(merge_data2$Month)


top_customer <- function(df,x,y){
  library(dplyr)
  ifelse(is.character(x)
         ,df %>% 
           select(City,Amount,Customer,Product,year,updated_months) %>%
           group_by(City,Customer) %>%
           filter(updated_months == x & Product == y) %>% 
           summarise(Tot_repay=sum(Amount,na.rm=T)) %>% 
           arrange(desc(Tot_repay)) %>%
           head(10)
         , df %>% 
           select(City,Amount,Customer,Product,year,updated_months) %>%
           group_by(City,Customer) %>%
           filter(year == x & Product == y) %>%
           summarise(Tot_repay=sum(Amount,na.rm=T)) %>% 
           arrange(desc(Tot_repay)) %>% 
           head(10))
         }

top_customer(merge_data2,2004,"Gold") ### User Function ##

## Need help in this, not able to return the exact output #########




























