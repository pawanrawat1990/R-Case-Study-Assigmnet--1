


##### Don't know how to create R mark down report , can you help #################

setwd("D:/R Analytics/Analytixlabs/R case study 1 (Retail)")
customer <- read.csv("Customer.csv")
prod_cat_info <- read.csv("prod_cat_info.csv")
transactions <- read.csv("Transactions.csv")

str(customer)
str(prod_cat_info)
str(transactions)

######## Question - 1 #####################################

cust_transac <- merge(transactions,customer,by.x="cust_id",by.y="customer_Id",all.x = TRUE)
customer_final <- merge(cust_transac,prod_cat_info,by.x=c("prod_cat_code","prod_subcat_code"),by.y = c("prod_cat_code","prod_sub_cat_code"),all.x = TRUE)


library(dplyr)


dplyr_cust_transac <- left_join(transactions,customer,c("cust_id"="customer_Id"))
dplyr_customer_final <- left_join(cust_transac,prod_cat_info,c("prod_cat_code","prod_subcat_code"="prod_sub_cat_code"))



######### Question - 2 ####################################

sapply(customer_final,class) ### col names and data types ##

sorted_cust_final <-  arrange(customer_final,desc(total_amt))

top_ten <-  sorted_cust_final[1:10,] ### Top 10 ###

bottom_ten <- tail(sorted_cust_final,10) ## Bottom 10 ###



#### Five-number summary ########

str(customer_final)

######## Changing the types of variables ##############

factor_var <- c("prod_cat_code","prod_subcat_code","city_code")
charac_var <- c("cust_id","transaction_id")


for(i in colnames(customer_final[factor_var])){
  customer_final[[i]] <- as.factor(customer_final[[i]])
}

for(i in colnames(customer_final[charac_var])){
  customer_final[[i]] <- as.character(customer_final[[i]])
}

customer_final$tran_date <-  pmax(
  as.Date(customer_final$tran_date, format="%m/%d/%Y"),
  as.Date(customer_final$tran_date, format="%d-%m-%Y"),na.rm=TRUE)

customer_final$DOB <-  pmax(
  as.Date(customer_final$DOB, format="%m/%d/%Y"),
  as.Date(customer_final$DOB, format="%d-%m-%Y"),na.rm=TRUE)


mystats <- function(x){
  min=min(x,na.rm = T)
  max=max(x,na.rm = T)
  median=median(x,na.rm = T)
  q1=quantile(x,0.25,na.rm = T)
  q3=quantile(x,0.75,na.rm=T)
  return(c(min=min,max=max,median=median,qi=q1,q3=q3))
}


numeric_var <- sapply(customer_final, is.numeric)
other_var <- sapply(customer_final, is.factor)


diag_stats <- t(data.frame(apply(customer_final[numeric_var],2,mystats)))

for(i in colnames(customer_final[other_var])){
  print(paste("Frequency of Category-",i))
  print(table(customer_final[[i]]))
}


#### Question-3 ##########

library(ggplot2)
library(reshape2)
library(cowplot)



x1 <- ggplot(customer_final)+geom_histogram(aes(Qty),fill="blue",binwidth=0.5)
x2 <- ggplot(customer_final)+geom_histogram(aes(Rate),fill="blue",binwidth=0.5)
x3 <- ggplot(customer_final)+geom_histogram(aes(Tax),fill="blue",binwidth=0.5)
x4 <- ggplot(customer_final)+geom_histogram(aes(total_amt),fill="blue",binwidth=0.5)

plot_grid(x1,x2,x3,x4) #### All continuous variables ######

y1 <- ggplot(customer_final)+geom_bar(aes(Store_type),fill="coral1")
y2 <- ggplot(customer_final)+geom_bar(aes(Gender),fill="coral1")
y3 <- ggplot(customer_final)+geom_bar(aes(city_code),fill="coral1")
y4 <- ggplot(customer_final)+geom_bar(aes(prod_cat),fill="coral1")
y5 <- ggplot(customer_final)+geom_bar(aes(prod_subcat),fill="coral1")

plot_grid(y1,y2,y3,y4,y5, nrow=3) #### All frequency plots #########



###### Question-4 ##################################

library(lubridate)
min_time <- min(year(customer_final$tran_date))
max_time <- max(year(customer_final$tran_date))

time_period <- max_time-min_time ####  3 Years #############


sum(customer_final$total_amt<0) ### Transactions less than 0 #########

###### Question-5 ######

table(customer_final$Gender,customer_final$prod_cat)  ## Books are popular among male and female ####


#### Question- 6 ##########

library(sqldf)

grp_city <- sqldf("select city_code,count(distinct(customer_Id)) as Num_of_customer 
      from customer
      group by city_code")

max_city_customer <- grp_city[which.max(grp_city$Num_of_customer),]

((max_city_customer$Num_of_customer/sum(grp_city$Num_of_customer))*100)


######## Question-7 #################

store_type <-  sqldf("select Store_type ,sum(total_amt) as value,sum(Qty) as quantity 
      from customer_final
      group by Store_type")

store_type[which.max(store_type$value),] ### E-Shop ########
store_type[which.max(store_type$quantity),] ### E-shop ####


####### Question-8 ###################################

Elec_clothing <- customer_final[customer_final$Store_type=="Flagship store" & (customer_final$prod_cat== "Electronics" | customer_final$prod_cat== "Clothing") ,]

sum(Elec_clothing$total_amt) #### 3409559 ####

male_elec <- customer_final[customer_final$Gender=="M" & customer_final$prod_cat=="Electronics",]

sum(male_elec$total_amt) ## 5703109 ##


###### Question-10 ########################

positive_transac <- customer_final[customer_final$total_amt>=0,]

group_dis_transac <-  sqldf("select cust_id,count(distinct(transaction_id)) as Num_of_transaction 
      from positive_transac
      group by cust_id")

sum(group_dis_transac$Num_of_transaction>10) #### 6 customers


##### Question-11 ##########################
####### a ################

today_date <- as.Date(c("2019-12-1"))

customer_final$age <- year(today_date)-year(customer_final$DOB)

elect_books <- customer_final[customer_final$age>=25 & customer_final$age<=35 & (customer_final$prod_cat=="Electronics" | customer_final$prod_cat=="Books"),]

sum(elect_books$total_amt) #### 9195096 ##########

###### b ####################

cust_2014 <- customer_final[customer_final$age>=25 & customer_final$age<=35 & customer_final$tran_date>"2014-01-01" & customer_final$tran_date<"2014-03-01",]

sum(cust_2014$total_amt) ### 556395 ####





#### END #######################################





