
### Question-1 ############################
customer_data <- read.csv("D:/R Analytics/Analytixlabs/Assignments/Customers.csv")


########### Question-2 ########################################
View(customer_data)

head(customer_data,5)

str(customer_data)

dim(customer_data)

colnames(customer_data)

sum(duplicated(customer_data))

##### Question-3 ##############################################

missing_value <-  sum(is.na(customer_data$Customer.Value))

total_count <- length(customer_data$Customer.Value)

missing_cust_value_percent <-  (missing_value/total_count)*100
#### 0.36 #####

####### Question-4 ########################################

unique_subset <- unique(customer_data)
duplicate_subset <- customer_data[duplicated(customer_data),]

###### Question-5 #################################

cust_data2 <- customer_data[customer_data$Customer.Value>10000,]

############ Question-6 ####################################

customer_data$Customer_Value_Segment <- ifelse(customer_data$Customer.Value>25000,"High Value Segment",
                                               ifelse(customer_data$Customer.Value<= 10000,"Low Value Segment","Medium Value Segment"))


########### Question-7 #########################################

customer_data$Avg_Revenue_Per_Trip <- customer_data$Customer.Value/customer_data$buy.times

customer_data$Balance_Points <- customer_data$Points.earned-customer_data$Points.redeemed

############ Question-8 #########################################

str(customer_data)

today <- as.Date(Sys.Date())

customer_data$recent.date <- as.character(customer_data$recent.date)
customer_data$recent.date <- as.Date(customer_data$recent.date,format="%Y%m%d")
customer_data$days <- customer_data$recent.date-today

########### Question-9 ##########################################

library(dplyr)
library(sqldf)

names(customer_data)


###### By city ##################
last_cities<-group_by(customer_data,Last_city)
sales_last_cities <- summarize(last_cities,total_cnt=n(), city_sales=sum(Customer.Value,na.rm = T))

total_sales <- sum(customer_data$Customer.Value,na.rm = T) ### Common ####

sales_last_cities$perc_sales <- (sales_last_cities$city_sales/total_sales)*100

################## By state #####################

last_state <- group_by(customer_data,Last_state)
sales_last_state <- summarise(last_state,total_cnt=n(), state_sales=sum(Customer.Value,na.rm = T))
sales_last_state$perc_sales <- (sales_last_state$state_sales/total_sales)*100

################### By Region #################

last_region <- group_by(customer_data,Last_region)
sales_last_region <- summarise(last_region,total_cnt=n(),region_sales=sum(Customer.Value,na.rm=T))
sales_last_region$perc_sales <- (sales_last_region$region_sales/total_sales)*100


######### Question -20 ###########################

names(customer_data)

library(dplyr)

grp_1 <- group_by(customer_data,Last_state,Last_city)
purchase_grp <- summarise(grp_1,total_cnt=n(), purchase_trx=sum(buy.times,na.rm = T),purchases=sum(Customer.Value,na.rm = T))
final_purchase_group <- mutate(purchase_grp,
                               avg_num_purchase=purchase_trx/total_cnt,
                               avg_purchase_tra_val=purchases/purchase_trx)




############### END #########################################








